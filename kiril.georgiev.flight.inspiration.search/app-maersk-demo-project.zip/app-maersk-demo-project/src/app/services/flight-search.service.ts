import { Injectable } from '@angular/core';
import { Observable, BehaviorSubject } from 'rxjs';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { REMOTE_DATA_MOCK } from '../utils/static';
import { catchError, tap } from "rxjs/operators";

export interface FlightDestinations {
    data: Array<FlightDestination>;

};

export interface FlightDestination {
    type: string;
    origin: string;
    destination: string;
    departureDate: string;
    returnDate: string;
    price: Price;
    links: any;
};

export interface Price {
    total: string;
};

export interface FlightSearch {
    origin: string;
    departureDate?: string;
    oneWay?: boolean;
    duration?: string;
    nonStop?: boolean;
    maxPrice?: number;
    viewBy?: string;
}

@Injectable({
    providedIn: 'root'
})
export class FlightSearchService {

    private submitFlightSearchEvent: BehaviorSubject<FlightSearch> = new BehaviorSubject<FlightSearch>(null);
    private accessToken = "";

    constructor(
        private http: HttpClient
    ) {
        this.getAccessToken().subscribe(token => {
            this.accessToken = token.access_token;
            console.log(this.accessToken)
        });
    }

    submit(flightSearch: FlightSearch) {
        this.submitFlightSearchEvent.next(flightSearch);
    }

    getFlightsMock(flightSearch: FlightSearch): Observable<FlightDestinations> {
        return new Observable((observer) => {
            const responseBody = REMOTE_DATA_MOCK;
            observer.next(responseBody);
            observer.complete();

        });
    }

    getFlights(flightSearch: FlightSearch): Observable<FlightDestinations> {
        let url: string = "https://test.api.amadeus.com/v1/shopping/flight-destinations?origin=" + flightSearch.origin + "&";
        if (flightSearch.departureDate) {
            url += "departureDate=" + flightSearch.departureDate + "&";
        }
        if (flightSearch.oneWay) {
            url += "oneWay=" + flightSearch.oneWay.toString() + "&";
        }
        if (flightSearch.duration) {
            url += "duration=" + flightSearch.duration + "&"
        }
        if (flightSearch.nonStop) {
            url += "nonStop=" + flightSearch.nonStop.toString() + "&"
        }
        if (flightSearch.maxPrice) {
            url += "maxPrice=" + flightSearch.maxPrice + "&"
        }
        if (flightSearch.viewBy) {
            url += "viewBy=" + flightSearch.viewBy;
        }
        console.log("URL: " + encodeURI(url));
        const headers: any = {
            headers: new HttpHeaders({
                "Authorization": "Bearer " + this.accessToken
            })
        };

        return this.http
            .get(
                encodeURI(url),
                headers
            )
            .pipe(
                tap(response => console.log("Token received: " + JSON.stringify(response))),
                catchError((err, result?: any): Observable<any> => {
                    console.error("HTTP ERROR " + JSON.stringify(err))
                    throw err;
                })
            );
    }

    submitFlightSearchEventObservable(): Observable<FlightSearch> {
        return this.submitFlightSearchEvent.asObservable();
    }

    getAccessToken(): Observable<any> {
        const url = "https://test.api.amadeus.com/v1/security/oauth2/token";
        const body = "client_id=DGrWQTf0ajCdhpfrEQUbkQuprJvk4Q4n&client_secret=XA49iR1tAvXNvAt0&grant_type=client_credentials";
        const headers: any = {
            headers: new HttpHeaders({
                "Content-Type": "application/x-www-form-urlencoded"
            })
        };

        return this.http
            .post(
                url,
                body,
                headers
            )
            .pipe(
                tap(response => console.log("Token received: " + JSON.stringify(response))),
                catchError((err, result?: any): Observable<any> => {
                    console.error("HTTP ERROR " + JSON.stringify(err))
                    throw err;
                })
            );
    }
}
