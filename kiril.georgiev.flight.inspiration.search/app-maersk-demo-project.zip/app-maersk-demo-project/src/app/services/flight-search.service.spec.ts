import { TestBed } from '@angular/core/testing';

import { FlightSearchService } from './flight-search.service';
import { HttpClientModule } from '@angular/common/http';

describe('FlightSearchService', () => {
    let service: FlightSearchService;

    beforeEach(() => {
        TestBed.configureTestingModule({
            imports: [
                HttpClientModule,
            ]
        });
        service = TestBed.inject(FlightSearchService);
    });

    it('should be created', () => {
        expect(service).toBeTruthy();
    });
});
