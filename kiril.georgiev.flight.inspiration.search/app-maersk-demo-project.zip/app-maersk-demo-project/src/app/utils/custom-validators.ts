import { AbstractControl } from '@angular/forms';
import * as moment from 'moment';

const MAX_END_DATE = 180;
const REG_EX_ALPHABETIC = /^[A-Za-z]+$/;

export class CustomValidators {

    static isAlphabetic() {
        return (control: AbstractControl): { [key: string]: any } | null => {
            const forbidden: boolean = !REG_EX_ALPHABETIC.test(control.value);
            return control.value && forbidden ? { forbiddenIATACode: { value: control.value } } : null;
        };
    }

    static isStartDateValid() {
        const nowDate = moment().format("YYYY-MM-DD");
        return (control: AbstractControl): { [key: string]: any } | null => {
            //Past dates should not be selected
            return (control.value !== "" && moment(new Date(control.value).toISOString()).format("YYYY-MM-DD") < nowDate) ?
                { startDateInvalid: { value: control.value } } : {};
        };
    }

    static isEndDateValid() {
        const latestDate = moment().add(MAX_END_DATE, "days").format("YYYY-MM-DD");
        return (control: AbstractControl): { [key: string]: any } | null => {
            //Past dates should not be selected
            return (control.value !== "" && moment(new Date(control.value).toISOString()).format("YYYY-MM-DD") > latestDate) ?
                { endDateInvalid: { value: control.value } } : {};
        };
    }

    static hasDecimals() {
        return (control: AbstractControl): { [key: string]: any } | null => {
            return (control.value - Math. floor(control.value)) !== 0 ?{ hasDecimals: { value: control.value } } : {};
        };
    }
}