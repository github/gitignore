export const REMOTE_DATA_MOCK = {
    "data": [
        {
            "type": "flight-destination",
            "origin": "MAD",
            "destination": "ALC",
            "departureDate": "2020-10-23",
            "returnDate": "2020-10-26",
            "price": {
                "total": "52.52"
            },
            "links": {
                "flightDates": "https://test.api.amadeus.com/v1/shopping/flight-dates?origin=MAD&destination=ALC&departureDate=2020-07-24,2021-01-19&oneWay=false&duration=1,15&nonStop=false&viewBy=DURATION",
                "flightOffers": "https://test.api.amadeus.com/v2/shopping/flight-offers?originLocationCode=MAD&destinationLocationCode=ALC&departureDate=2020-10-23&returnDate=2020-10-26&adults=1&nonStop=false"
            }
        },
        {
            "type": "flight-destination",
            "origin": "MAD",
            "destination": "LON",
            "departureDate": "2020-10-22",
            "returnDate": "2020-10-25",
            "price": {
                "total": "71.15"
            },
            "links": {
                "flightDates": "https://test.api.amadeus.com/v1/shopping/flight-dates?origin=MAD&destination=LON&departureDate=2020-07-24,2021-01-19&oneWay=false&duration=1,15&nonStop=false&viewBy=DURATION",
                "flightOffers": "https://test.api.amadeus.com/v2/shopping/flight-offers?originLocationCode=MAD&destinationLocationCode=LON&departureDate=2020-10-22&returnDate=2020-10-25&adults=1&nonStop=false"
            }
        },
        {
            "type": "flight-destination",
            "origin": "MAD",
            "destination": "MUC",
            "departureDate": "2020-08-12",
            "returnDate": "2020-08-17",
            "price": {
                "total": "98.53"
            },
            "links": {
                "flightDates": "https://test.api.amadeus.com/v1/shopping/flight-dates?origin=MAD&destination=MUC&departureDate=2020-07-24,2021-01-19&oneWay=false&duration=1,15&nonStop=false&viewBy=DURATION",
                "flightOffers": "https://test.api.amadeus.com/v2/shopping/flight-offers?originLocationCode=MAD&destinationLocationCode=MUC&departureDate=2020-08-12&returnDate=2020-08-17&adults=1&nonStop=false"
            }
        },
        {
            "type": "flight-destination",
            "origin": "MAD",
            "destination": "WAW",
            "departureDate": "2020-07-30",
            "returnDate": "2020-08-06",
            "price": {
                "total": "108.30"
            },
            "links": {
                "flightDates": "https://test.api.amadeus.com/v1/shopping/flight-dates?origin=MAD&destination=WAW&departureDate=2020-07-24,2021-01-19&oneWay=false&duration=1,15&nonStop=false&viewBy=DURATION",
                "flightOffers": "https://test.api.amadeus.com/v2/shopping/flight-offers?originLocationCode=MAD&destinationLocationCode=WAW&departureDate=2020-07-30&returnDate=2020-08-06&adults=1&nonStop=false"
            }
        },
        {
            "type": "flight-destination",
            "origin": "MAD",
            "destination": "KRK",
            "departureDate": "2020-07-25",
            "returnDate": "2020-08-01",
            "price": {
                "total": "116.81"
            },
            "links": {
                "flightDates": "https://test.api.amadeus.com/v1/shopping/flight-dates?origin=MAD&destination=KRK&departureDate=2020-07-24,2021-01-19&oneWay=false&duration=1,15&nonStop=false&viewBy=DURATION",
                "flightOffers": "https://test.api.amadeus.com/v2/shopping/flight-offers?originLocationCode=MAD&destinationLocationCode=KRK&departureDate=2020-07-25&returnDate=2020-08-01&adults=1&nonStop=false"
            }
        },
        {
            "type": "flight-destination",
            "origin": "MAD",
            "destination": "GOA",
            "departureDate": "2020-09-07",
            "returnDate": "2020-09-11",
            "price": {
                "total": "123.78"
            },
            "links": {
                "flightDates": "https://test.api.amadeus.com/v1/shopping/flight-dates?origin=MAD&destination=GOA&departureDate=2020-07-24,2021-01-19&oneWay=false&duration=1,15&nonStop=false&viewBy=DURATION",
                "flightOffers": "https://test.api.amadeus.com/v2/shopping/flight-offers?originLocationCode=MAD&destinationLocationCode=GOA&departureDate=2020-09-07&returnDate=2020-09-11&adults=1&nonStop=false"
            }
        },
        {
            "type": "flight-destination",
            "origin": "MAD",
            "destination": "VIE",
            "departureDate": "2020-07-31",
            "returnDate": "2020-08-05",
            "price": {
                "total": "124.27"
            },
            "links": {
                "flightDates": "https://test.api.amadeus.com/v1/shopping/flight-dates?origin=MAD&destination=VIE&departureDate=2020-07-24,2021-01-19&oneWay=false&duration=1,15&nonStop=false&viewBy=DURATION",
                "flightOffers": "https://test.api.amadeus.com/v2/shopping/flight-offers?originLocationCode=MAD&destinationLocationCode=VIE&departureDate=2020-07-31&returnDate=2020-08-05&adults=1&nonStop=false"
            }
        },
        {
            "type": "flight-destination",
            "origin": "MAD",
            "destination": "VCE",
            "departureDate": "2020-10-25",
            "returnDate": "2020-10-26",
            "price": {
                "total": "127.96"
            },
            "links": {
                "flightDates": "https://test.api.amadeus.com/v1/shopping/flight-dates?origin=MAD&destination=VCE&departureDate=2020-07-24,2021-01-19&oneWay=false&duration=1,15&nonStop=false&viewBy=DURATION",
                "flightOffers": "https://test.api.amadeus.com/v2/shopping/flight-offers?originLocationCode=MAD&destinationLocationCode=VCE&departureDate=2020-10-25&returnDate=2020-10-26&adults=1&nonStop=false"
            }
        },
        {
            "type": "flight-destination",
            "origin": "MAD",
            "destination": "GOT",
            "departureDate": "2020-08-02",
            "returnDate": "2020-08-16",
            "price": {
                "total": "147.78"
            },
            "links": {
                "flightDates": "https://test.api.amadeus.com/v1/shopping/flight-dates?origin=MAD&destination=GOT&departureDate=2020-07-24,2021-01-19&oneWay=false&duration=1,15&nonStop=false&viewBy=DURATION",
                "flightOffers": "https://test.api.amadeus.com/v2/shopping/flight-offers?originLocationCode=MAD&destinationLocationCode=GOT&departureDate=2020-08-02&returnDate=2020-08-16&adults=1&nonStop=false"
            }
        },
        {
            "type": "flight-destination",
            "origin": "MAD",
            "destination": "LWO",
            "departureDate": "2020-07-30",
            "returnDate": "2020-08-04",
            "price": {
                "total": "158.29"
            },
            "links": {
                "flightDates": "https://test.api.amadeus.com/v1/shopping/flight-dates?origin=MAD&destination=LWO&departureDate=2020-07-24,2021-01-19&oneWay=false&duration=1,15&nonStop=false&viewBy=DURATION",
                "flightOffers": "https://test.api.amadeus.com/v2/shopping/flight-offers?originLocationCode=MAD&destinationLocationCode=LWO&departureDate=2020-07-30&returnDate=2020-08-04&adults=1&nonStop=false"
            }
        },
        {
            "type": "flight-destination",
            "origin": "MAD",
            "destination": "GLA",
            "departureDate": "2020-09-01",
            "returnDate": "2020-09-04",
            "price": {
                "total": "162.72"
            },
            "links": {
                "flightDates": "https://test.api.amadeus.com/v1/shopping/flight-dates?origin=MAD&destination=GLA&departureDate=2020-07-24,2021-01-19&oneWay=false&duration=1,15&nonStop=false&viewBy=DURATION",
                "flightOffers": "https://test.api.amadeus.com/v2/shopping/flight-offers?originLocationCode=MAD&destinationLocationCode=GLA&departureDate=2020-09-01&returnDate=2020-09-04&adults=1&nonStop=false"
            }
        },
        {
            "type": "flight-destination",
            "origin": "MAD",
            "destination": "CLJ",
            "departureDate": "2020-10-14",
            "returnDate": "2020-10-22",
            "price": {
                "total": "163.16"
            },
            "links": {
                "flightDates": "https://test.api.amadeus.com/v1/shopping/flight-dates?origin=MAD&destination=CLJ&departureDate=2020-07-24,2021-01-19&oneWay=false&duration=1,15&nonStop=false&viewBy=DURATION",
                "flightOffers": "https://test.api.amadeus.com/v2/shopping/flight-offers?originLocationCode=MAD&destinationLocationCode=CLJ&departureDate=2020-10-14&returnDate=2020-10-22&adults=1&nonStop=false"
            }
        },
        {
            "type": "flight-destination",
            "origin": "MAD",
            "destination": "RIX",
            "departureDate": "2020-08-03",
            "returnDate": "2020-08-10",
            "price": {
                "total": "167.72"
            },
            "links": {
                "flightDates": "https://test.api.amadeus.com/v1/shopping/flight-dates?origin=MAD&destination=RIX&departureDate=2020-07-24,2021-01-19&oneWay=false&duration=1,15&nonStop=false&viewBy=DURATION",
                "flightOffers": "https://test.api.amadeus.com/v2/shopping/flight-offers?originLocationCode=MAD&destinationLocationCode=RIX&departureDate=2020-08-03&returnDate=2020-08-10&adults=1&nonStop=false"
            }
        },
        {
            "type": "flight-destination",
            "origin": "MAD",
            "destination": "TLL",
            "departureDate": "2020-08-05",
            "returnDate": "2020-08-11",
            "price": {
                "total": "167.75"
            },
            "links": {
                "flightDates": "https://test.api.amadeus.com/v1/shopping/flight-dates?origin=MAD&destination=TLL&departureDate=2020-07-24,2021-01-19&oneWay=false&duration=1,15&nonStop=false&viewBy=DURATION",
                "flightOffers": "https://test.api.amadeus.com/v2/shopping/flight-offers?originLocationCode=MAD&destinationLocationCode=TLL&departureDate=2020-08-05&returnDate=2020-08-11&adults=1&nonStop=false"
            }
        },
        {
            "type": "flight-destination",
            "origin": "MAD",
            "destination": "MOW",
            "departureDate": "2020-07-28",
            "returnDate": "2020-08-03",
            "price": {
                "total": "176.63"
            },
            "links": {
                "flightDates": "https://test.api.amadeus.com/v1/shopping/flight-dates?origin=MAD&destination=MOW&departureDate=2020-07-24,2021-01-19&oneWay=false&duration=1,15&nonStop=false&viewBy=DURATION",
                "flightOffers": "https://test.api.amadeus.com/v2/shopping/flight-offers?originLocationCode=MAD&destinationLocationCode=MOW&departureDate=2020-07-28&returnDate=2020-08-03&adults=1&nonStop=false"
            }
        },
        {
            "type": "flight-destination",
            "origin": "MAD",
            "destination": "KIV",
            "departureDate": "2020-11-01",
            "returnDate": "2020-11-16",
            "price": {
                "total": "220.51"
            },
            "links": {
                "flightDates": "https://test.api.amadeus.com/v1/shopping/flight-dates?origin=MAD&destination=KIV&departureDate=2020-07-24,2021-01-19&oneWay=false&duration=1,15&nonStop=false&viewBy=DURATION",
                "flightOffers": "https://test.api.amadeus.com/v2/shopping/flight-offers?originLocationCode=MAD&destinationLocationCode=KIV&departureDate=2020-11-01&returnDate=2020-11-16&adults=1&nonStop=false"
            }
        },
        {
            "type": "flight-destination",
            "origin": "MAD",
            "destination": "BOS",
            "departureDate": "2020-07-30",
            "returnDate": "2020-08-14",
            "price": {
                "total": "289.78"
            },
            "links": {
                "flightDates": "https://test.api.amadeus.com/v1/shopping/flight-dates?origin=MAD&destination=BOS&departureDate=2020-07-24,2021-01-19&oneWay=false&duration=1,15&nonStop=false&viewBy=DURATION",
                "flightOffers": "https://test.api.amadeus.com/v2/shopping/flight-offers?originLocationCode=MAD&destinationLocationCode=BOS&departureDate=2020-07-30&returnDate=2020-08-14&adults=1&nonStop=false"
            }
        },
        {
            "type": "flight-destination",
            "origin": "MAD",
            "destination": "MTY",
            "departureDate": "2020-10-18",
            "returnDate": "2020-10-19",
            "price": {
                "total": "326.09"
            },
            "links": {
                "flightDates": "https://test.api.amadeus.com/v1/shopping/flight-dates?origin=MAD&destination=MTY&departureDate=2020-07-24,2021-01-19&oneWay=false&duration=1,15&nonStop=false&viewBy=DURATION",
                "flightOffers": "https://test.api.amadeus.com/v2/shopping/flight-offers?originLocationCode=MAD&destinationLocationCode=MTY&departureDate=2020-10-18&returnDate=2020-10-19&adults=1&nonStop=false"
            }
        },
        {
            "type": "flight-destination",
            "origin": "MAD",
            "destination": "FLL",
            "departureDate": "2020-10-31",
            "returnDate": "2020-11-01",
            "price": {
                "total": "359.01"
            },
            "links": {
                "flightDates": "https://test.api.amadeus.com/v1/shopping/flight-dates?origin=MAD&destination=FLL&departureDate=2020-07-24,2021-01-19&oneWay=false&duration=1,15&nonStop=false&viewBy=DURATION",
                "flightOffers": "https://test.api.amadeus.com/v2/shopping/flight-offers?originLocationCode=MAD&destinationLocationCode=FLL&departureDate=2020-10-31&returnDate=2020-11-01&adults=1&nonStop=false"
            }
        },
        {
            "type": "flight-destination",
            "origin": "MAD",
            "destination": "DEN",
            "departureDate": "2020-10-18",
            "returnDate": "2020-10-19",
            "price": {
                "total": "386.82"
            },
            "links": {
                "flightDates": "https://test.api.amadeus.com/v1/shopping/flight-dates?origin=MAD&destination=DEN&departureDate=2020-07-24,2021-01-19&oneWay=false&duration=1,15&nonStop=false&viewBy=DURATION",
                "flightOffers": "https://test.api.amadeus.com/v2/shopping/flight-offers?originLocationCode=MAD&destinationLocationCode=DEN&departureDate=2020-10-18&returnDate=2020-10-19&adults=1&nonStop=false"
            }
        },
        {
            "type": "flight-destination",
            "origin": "MAD",
            "destination": "ACC",
            "departureDate": "2020-10-17",
            "returnDate": "2020-10-27",
            "price": {
                "total": "428.52"
            },
            "links": {
                "flightDates": "https://test.api.amadeus.com/v1/shopping/flight-dates?origin=MAD&destination=ACC&departureDate=2020-07-24,2021-01-19&oneWay=false&duration=1,15&nonStop=false&viewBy=DURATION",
                "flightOffers": "https://test.api.amadeus.com/v2/shopping/flight-offers?originLocationCode=MAD&destinationLocationCode=ACC&departureDate=2020-10-17&returnDate=2020-10-27&adults=1&nonStop=false"
            }
        },
        {
            "type": "flight-destination",
            "origin": "MAD",
            "destination": "ORL",
            "departureDate": "2020-09-05",
            "returnDate": "2020-09-06",
            "price": {
                "total": "433.09"
            },
            "links": {
                "flightDates": "https://test.api.amadeus.com/v1/shopping/flight-dates?origin=MAD&destination=ORL&departureDate=2020-07-24,2021-01-19&oneWay=false&duration=1,15&nonStop=false&viewBy=DURATION",
                "flightOffers": "https://test.api.amadeus.com/v2/shopping/flight-offers?originLocationCode=MAD&destinationLocationCode=ORL&departureDate=2020-09-05&returnDate=2020-09-06&adults=1&nonStop=false"
            }
        },
        {
            "type": "flight-destination",
            "origin": "MAD",
            "destination": "TYO",
            "departureDate": "2020-08-04",
            "returnDate": "2020-08-10",
            "price": {
                "total": "456.05"
            },
            "links": {
                "flightDates": "https://test.api.amadeus.com/v1/shopping/flight-dates?origin=MAD&destination=TYO&departureDate=2020-07-24,2021-01-19&oneWay=false&duration=1,15&nonStop=false&viewBy=DURATION",
                "flightOffers": "https://test.api.amadeus.com/v2/shopping/flight-offers?originLocationCode=MAD&destinationLocationCode=TYO&departureDate=2020-08-04&returnDate=2020-08-10&adults=1&nonStop=false"
            }
        },
        {
            "type": "flight-destination",
            "origin": "MAD",
            "destination": "SSA",
            "departureDate": "2020-08-02",
            "returnDate": "2020-08-03",
            "price": {
                "total": "459.73"
            },
            "links": {
                "flightDates": "https://test.api.amadeus.com/v1/shopping/flight-dates?origin=MAD&destination=SSA&departureDate=2020-07-24,2021-01-19&oneWay=false&duration=1,15&nonStop=false&viewBy=DURATION",
                "flightOffers": "https://test.api.amadeus.com/v2/shopping/flight-offers?originLocationCode=MAD&destinationLocationCode=SSA&departureDate=2020-08-02&returnDate=2020-08-03&adults=1&nonStop=false"
            }
        },
        {
            "type": "flight-destination",
            "origin": "MAD",
            "destination": "MGA",
            "departureDate": "2020-10-20",
            "returnDate": "2020-10-27",
            "price": {
                "total": "484.84"
            },
            "links": {
                "flightDates": "https://test.api.amadeus.com/v1/shopping/flight-dates?origin=MAD&destination=MGA&departureDate=2020-07-24,2021-01-19&oneWay=false&duration=1,15&nonStop=false&viewBy=DURATION",
                "flightOffers": "https://test.api.amadeus.com/v2/shopping/flight-offers?originLocationCode=MAD&destinationLocationCode=MGA&departureDate=2020-10-20&returnDate=2020-10-27&adults=1&nonStop=false"
            }
        },
        {
            "type": "flight-destination",
            "origin": "MAD",
            "destination": "SIN",
            "departureDate": "2020-11-06",
            "returnDate": "2020-11-10",
            "price": {
                "total": "521.21"
            },
            "links": {
                "flightDates": "https://test.api.amadeus.com/v1/shopping/flight-dates?origin=MAD&destination=SIN&departureDate=2020-07-24,2021-01-19&oneWay=false&duration=1,15&nonStop=false&viewBy=DURATION",
                "flightOffers": "https://test.api.amadeus.com/v2/shopping/flight-offers?originLocationCode=MAD&destinationLocationCode=SIN&departureDate=2020-11-06&returnDate=2020-11-10&adults=1&nonStop=false"
            }
        },
        {
            "type": "flight-destination",
            "origin": "MAD",
            "destination": "CCS",
            "departureDate": "2020-09-08",
            "returnDate": "2020-09-15",
            "price": {
                "total": "528.17"
            },
            "links": {
                "flightDates": "https://test.api.amadeus.com/v1/shopping/flight-dates?origin=MAD&destination=CCS&departureDate=2020-07-24,2021-01-19&oneWay=false&duration=1,15&nonStop=false&viewBy=DURATION",
                "flightOffers": "https://test.api.amadeus.com/v2/shopping/flight-offers?originLocationCode=MAD&destinationLocationCode=CCS&departureDate=2020-09-08&returnDate=2020-09-15&adults=1&nonStop=false"
            }
        },
        {
            "type": "flight-destination",
            "origin": "MAD",
            "destination": "SLC",
            "departureDate": "2020-10-16",
            "returnDate": "2020-10-17",
            "price": {
                "total": "550.01"
            },
            "links": {
                "flightDates": "https://test.api.amadeus.com/v1/shopping/flight-dates?origin=MAD&destination=SLC&departureDate=2020-07-24,2021-01-19&oneWay=false&duration=1,15&nonStop=false&viewBy=DURATION",
                "flightOffers": "https://test.api.amadeus.com/v2/shopping/flight-offers?originLocationCode=MAD&destinationLocationCode=SLC&departureDate=2020-10-16&returnDate=2020-10-17&adults=1&nonStop=false"
            }
        },
        {
            "type": "flight-destination",
            "origin": "MAD",
            "destination": "SEA",
            "departureDate": "2020-10-31",
            "returnDate": "2020-11-01",
            "price": {
                "total": "590.64"
            },
            "links": {
                "flightDates": "https://test.api.amadeus.com/v1/shopping/flight-dates?origin=MAD&destination=SEA&departureDate=2020-07-24,2021-01-19&oneWay=false&duration=1,15&nonStop=false&viewBy=DURATION",
                "flightOffers": "https://test.api.amadeus.com/v2/shopping/flight-offers?originLocationCode=MAD&destinationLocationCode=SEA&departureDate=2020-10-31&returnDate=2020-11-01&adults=1&nonStop=false"
            }
        },
        {
            "type": "flight-destination",
            "origin": "MAD",
            "destination": "RGN",
            "departureDate": "2020-08-27",
            "returnDate": "2020-08-30",
            "price": {
                "total": "628.70"
            },
            "links": {
                "flightDates": "https://test.api.amadeus.com/v1/shopping/flight-dates?origin=MAD&destination=RGN&departureDate=2020-07-24,2021-01-19&oneWay=false&duration=1,15&nonStop=false&viewBy=DURATION",
                "flightOffers": "https://test.api.amadeus.com/v2/shopping/flight-offers?originLocationCode=MAD&destinationLocationCode=RGN&departureDate=2020-08-27&returnDate=2020-08-30&adults=1&nonStop=false"
            }
        },
        {
            "type": "flight-destination",
            "origin": "MAD",
            "destination": "KTM",
            "departureDate": "2020-07-24",
            "returnDate": "2020-07-27",
            "price": {
                "total": "629.07"
            },
            "links": {
                "flightDates": "https://test.api.amadeus.com/v1/shopping/flight-dates?origin=MAD&destination=KTM&departureDate=2020-07-24,2021-01-19&oneWay=false&duration=1,15&nonStop=false&viewBy=DURATION",
                "flightOffers": "https://test.api.amadeus.com/v2/shopping/flight-offers?originLocationCode=MAD&destinationLocationCode=KTM&departureDate=2020-07-24&returnDate=2020-07-27&adults=1&nonStop=false"
            }
        },
        {
            "type": "flight-destination",
            "origin": "MAD",
            "destination": "MDZ",
            "departureDate": "2020-07-24",
            "returnDate": "2020-07-31",
            "price": {
                "total": "670.41"
            },
            "links": {
                "flightDates": "https://test.api.amadeus.com/v1/shopping/flight-dates?origin=MAD&destination=MDZ&departureDate=2020-07-24,2021-01-19&oneWay=false&duration=1,15&nonStop=false&viewBy=DURATION",
                "flightOffers": "https://test.api.amadeus.com/v2/shopping/flight-offers?originLocationCode=MAD&destinationLocationCode=MDZ&departureDate=2020-07-24&returnDate=2020-07-31&adults=1&nonStop=false"
            }
        },
        {
            "type": "flight-destination",
            "origin": "MAD",
            "destination": "HNL",
            "departureDate": "2020-09-13",
            "returnDate": "2020-09-18",
            "price": {
                "total": "1176.87"
            },
            "links": {
                "flightDates": "https://test.api.amadeus.com/v1/shopping/flight-dates?origin=MAD&destination=HNL&departureDate=2020-07-24,2021-01-19&oneWay=false&duration=1,15&nonStop=false&viewBy=DURATION",
                "flightOffers": "https://test.api.amadeus.com/v2/shopping/flight-offers?originLocationCode=MAD&destinationLocationCode=HNL&departureDate=2020-09-13&returnDate=2020-09-18&adults=1&nonStop=false"
            }
        }
    ]
};

