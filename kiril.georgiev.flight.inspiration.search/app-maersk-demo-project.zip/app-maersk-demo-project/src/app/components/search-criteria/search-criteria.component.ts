import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from "@angular/forms";
import { CustomValidators } from '../../utils/custom-validators';
import { Options } from 'ng5-slider';
import { FlightSearch, FlightSearchService } from '../../services/flight-search.service';
import * as moment from 'moment';

@Component({
    selector: 'app-search-criteria',
    templateUrl: './search-criteria.component.html',
    styleUrls: ['./search-criteria.component.scss']
})

export class SearchCriteriaComponent implements OnInit {
    
    // Main Form Group
    searchCriteriaFormGroup: FormGroup;
    
    // Some options for the slider
    value: number = 1;
    highValue: number = 2;
    options: Options = {
        floor: 1,
        ceil: 15,
        showTicksValues: false
    };
    
    // Better to use enum ...
    viewBy = [
        "NONE",
        "DATE",
        "DESTINATION",
        "DURATION",
        "WEEK",
        "COUNTRY"
    ];
    constructor(private flightSearchService: FlightSearchService) {

    }

    ngOnInit(): void {
        this.searchCriteriaFormGroup = new FormGroup({
            iataFormControl: new FormControl("", [
                Validators.required,
                Validators.minLength(3),
                Validators.maxLength(3),
                // Accept only [A-Z][a-z]
                CustomValidators.isAlphabetic()
            ]),
            rangeFormGroup: new FormGroup({
                startDateFormControl: new FormControl("", [
                    // Past dates are not accepted
                    CustomValidators.isStartDateValid()
                ]),
                endDateFormControl: new FormControl("", [
                    // Future dates greater then 180 days are not accepted 
                    CustomValidators.isEndDateValid()
                ])
            }),
            oneWayFormControl: new FormControl("", []),
            nonStopFormControl: new FormControl("", []),
            priceFormControl: new FormControl("", [
                Validators.min(0),
                // Number with decimals are not accepted
                CustomValidators.hasDecimals()
            ]),
            viewByFormControl: new FormControl("", [])
        });
    }

    /**
    * Sets the default value in viewBy to DATE, when oneWay is set to true
    * @param value The property checked contains the state of the oneWay slide toggle
    */
    onChangeOneWay(value) {
        if (value.checked) {
            this.searchCriteriaFormGroup.get("viewByFormControl").setValue(this.viewBy[1]);
        } else {
            this.searchCriteriaFormGroup.get("viewByFormControl").setValue(undefined);
        }
    }

    /**
    * Submit button click handler. It calls the service providing parsed flight search criteria  
    */
    submitSearchCriteria() {
        console.log("Request parameters: ", JSON.stringify(this.createFlightSearch()));
        this.flightSearchService.submit(this.createFlightSearch());
    }

    /**
    * Provides error messages to the view when the IATA input is wrong
    */
    getIATAErrorMessage() {
        if (this.iataInput.hasError("required")) {
            return "IATA code is required";
        }
        if (this.iataInput.hasError("minlength") || this.iataInput.hasError("maxlength")) {
            return "IATA code must be 3 characters long";
        }
        if (this.iataInput.hasError("forbiddenIATACode")) {
            return "IATA code must contain only alphabetic characters";
        }
    }

    /**
    * Provides error messages to the view when the Date input is wrong
    */
    getDateInputError() {
        if (this.startDateInput.hasError("startDateInvalid")) {
            return "Invalid start date";
        }
        if (this.endDateInput.hasError("endDateInvalid")) {
            return "Invalid end date, it must be 180 days from today";
        }
    }

    /**
    * Provides error messages to the view when the Price input is wrong
    */
    getPriceInputError() {
        if (this.priceInput.hasError("min")) {
            return "The price cannot be negative";
        }
        if (this.priceInput.hasError("hasDecimals")) {
            return "The price cannot have decimals";
        }
    }

    /**
    * Gets the flight search data from the view and assembles flightSearch object( used to create the URL
    * for retrieving flight destinations)
    */
    private createFlightSearch(): FlightSearch {
        const departureStartDate: string = this.startDateInput.value ?
            moment(new Date(this.startDateInput.value).toISOString()).format("YYYY-MM-DD") : null;
        const departureEndDate: string = this.startDateInput.value ?
            moment(new Date(this.startDateInput.value).toISOString()).format("YYYY-MM-DD") : null;
        // iataInput is required property so it will be allways there
        let flightSearch: FlightSearch = {
            origin: this.iataInput.value
        };
        if (departureStartDate) {
            if (departureEndDate) {
                flightSearch.departureDate = departureStartDate + "," + departureEndDate;
            } else {
                flightSearch.departureDate = departureStartDate;
            }
        }
        if (this.searchCriteriaFormGroup.get("oneWayFormControl").value) {
            flightSearch.oneWay = this.searchCriteriaFormGroup.get("oneWayFormControl").value;
        }
        if (this.searchCriteriaFormGroup.get("nonStopFormControl").value) {
            flightSearch.nonStop = this.searchCriteriaFormGroup.get("nonStopFormControl").value;
        }
        if (this.priceInput.value) {
            flightSearch.maxPrice = this.priceInput.value;
        }
        if (this.searchCriteriaFormGroup.get("viewByFormControl").value &&
            this.searchCriteriaFormGroup.get("viewByFormControl").value !== this.viewBy[0]) {
            flightSearch.viewBy = this.searchCriteriaFormGroup.get("viewByFormControl").value
        }
        if (!this.searchCriteriaFormGroup.get("oneWayFormControl").value) {
            flightSearch.duration = this.value + "," + this.highValue;
        }
        return flightSearch;
    }

    get iataInput() { return this.searchCriteriaFormGroup.get("iataFormControl"); }

    get startDateInput() { return this.searchCriteriaFormGroup.get("rangeFormGroup").get("startDateFormControl"); }

    get endDateInput() { return this.searchCriteriaFormGroup.get("rangeFormGroup").get("endDateFormControl"); }

    get priceInput() { return this.searchCriteriaFormGroup.get("priceFormControl"); }
}
