import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { FlightSearchService, FlightSearch, FlightDestination, FlightDestinations } from '../../services/flight-search.service';
import { MatPaginator } from '@angular/material/paginator';

@Component({
    selector: 'app-search-results',
    templateUrl: './search-results.component.html',
    styleUrls: ['./search-results.component.scss']
})
export class SearchResultsComponent implements OnInit {

    flightDestinationsDataSource: MatTableDataSource<FlightDestination>;
    columns: string[] = ['origin', 'destination', 'departureDate', 'returnDate', 'price'];
    DEFAULT_PAGE_SIZE_REF = 5;
    DEFAULT_PAGE_SIZE_OPTION_REF = [5,10];
    @ViewChild("flightDestinationsPaginator", { static: true }) flightDestinationsPaginator: MatPaginator;

    constructor(private flightSearchService: FlightSearchService) { }

    ngOnInit(): void {
        // Called when the subscribe button is clicked
        this.flightSearchService.submitFlightSearchEventObservable().subscribe((flightSearch: FlightSearch) => {
            // flightSearch will be null when the service is initialized because the corresponding BehaviorSubject is
            // initialized with null. The data should not be fetched in this case but only when the submit button is clicked
            if (flightSearch) {
                this.flightSearchService.getFlightsMock(flightSearch).subscribe((flightDestinations: FlightDestinations) => {
                    console.log(JSON.stringify(flightDestinations))
                    this.flightDestinationsDataSource = new MatTableDataSource(flightDestinations.data);
                    this.flightDestinationsDataSource.paginator = this.flightDestinationsPaginator;
                });
            }
        });
    }

}
