# AppMaerskDemoProject

This project was generated with [Angular CLI](https://github.com/angular/angular-cli) version 10.1.3.

The first three sections of this document describe the development process that I used to implement this project.
The forth one describes how to run it and test it.


### Analysis: defines the software requirements
In this project, the software requirements are driven by the server-side API. The main use-case is:

As a user, I want to find the best flight to a destination by using search criterias

This main use-case can further be split in:

As a user,

    I need to provide the correct origin

    I want to filter by departure date which starts in the present and is not more than 180 days in the future

    I want to filter by one way trip if I don't need to return

    I want to filter by the duration of the travel in a range between 1 and 15 days

    When I select one way trip, I don't need to specify the duration of the travel

    I want to filter by non stop travel

    I want to filter by the price of a travel without including decimals

    I want to filter destinations by DATE, DESTINATION, DURATION, WEEK, or COUNTRY

    I want to filter destination by DATE by default, when I flight only one way

    When I select all my search criteria, I want to see all the relevant flights

### Design: defines the architecture and the properties of the software

The requirements from the analysis can be translated into two components and one service:

Component 1: containing a form which contains all the filters and validates all the inputs from the user. This form can use:

    Input for the origin of the flight and its price

    Slider for the duration with two pointers to select a range

    Date picker for the range of departure dates

    Slide toggle for one-way/round-trip and for the non-stop travel

    Selection for filtering destinations by DATE, DESTINATION, DURATION, WEEK, or COUNTRY

    The form should be submitted only when it is validated

Component 2: containing a table which displays the relevant flights

Service: fetching the data for the relevant flights and orchestrating the interactions between the two components (when the form is submitted, the table should be filled)

### Implementation: tasks, choices and limitations

The project contains the following two components and a service: search-criteria, search-results and flight-search.service

search-criteria is implementation of the following tasks:

    Use MatInput for implemeting the inputs for the origin and for the price

    Use Ng5Slider for implementing the duration (the native MatSlider is not convenient because it does not allow to select a range). Note that in the current implementation, the duration is always set but there should ideally be a slidetoggle or a checkbox to show it or hide it when the user does not want to select a duration.

    Use MatDatepicker for implementing the Date-Range picker of the departure dates. Ideally past dates and dates after 180 days should be grayed but for simplification, error messages are shown and the form is marked as invalid. The package moment is used to easily manipulate dates.

    Use MatSlideToggle for implementing the one-way/round-trip and for the non-stop travel

    Use MatSelect for the view by

    Use form validators to implemented all the constraints described in the use-cases

search-results is implementation of the following tasks:

    Use MatTable for the flights data received from the service

    Use MatPaginator for paginating the table

flight-search.service:

    Create the response type for the flights data by using the OpenAPI spec file

    Create the request for getting the access token by providing client_id and client_secret

    Orchestrate the two components so that when the submit button is hit on the first component, the second component fetches the service data and displays it.

    Create the request for getting the flights data: during the exercise period, the server-side API was broken.
    https://test.api.amadeus.com/v1/shopping/flight-destinations... was always returning:

    {
      "errors": [
        {
          "status": 500,
          "code": 141,
          "title": "SYSTEM ERROR HAS OCCURRED",
          "detail": "Featured Results option is mandatory"
        }
      ]
    }

There is also discussion about the problem on

    https://stackoverflow.com/questions/64055297/amadeus-api-issue-with-the-flight-inspiration-search-api-in-test-mode

I think that it was realy broken because other APIs were working fine! Because of this, the project comes with a mock of the API, where the mocked data is extracted from the OpenAPI spec. The function returning the mock is called getFlightsMock in the service and the real function (getFlights) is implemented and can be tested as soon as the API is functional.

Other details

Tests: there is only one test, provided in search-criteria.component.spec.ts, which verifies that when the IATA code is too long, the form is invalid. Ideally, all the validation should be tested but since the testing is similar, it has not been done. The values of the table should also be tested by mocking the data from the service. Ideally at least 80% code coverage should be reached.
 
Internationalization: not covered but can be handled with the standard localization module in Angular

Types definitions: defined by using the OpenAPI spec file

Note: the server side API does not look ideal because it does not support pagination which can give a poor UX when the response is of a big size

### Run: execution of the software

1. Download and install npm and Angular
2. Run npm install
3. Run `ng serve` for a dev server. Navigate to `http://localhost:4200/`.
4. Run `ng test` to execute the unit tests 
